/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuefinder;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author acer
 */
public class QueueFinder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Semua tulisan yang diprint bersifat sementara!!!
        //(termasuk pengubahan tipe mobil dari int ke char)

        Scanner scan = new Scanner(System.in);
        System.out.print("Total mobil yang diproduksi: ");
        int totalMobil = scan.nextInt();
        System.out.print("Jumlah option: ");
        int jmlOption = scan.nextInt();
        System.out.print("Jumlah tipe mobil: ");
        int jmlTipe = scan.nextInt();
        System.out.println("");

        int[] mobilKerja = new int[jmlOption];
        int[] mobilMasuk = new int[jmlOption];

        //Capacity Constraint: mobilKerja : mobilMasuk
        for (int i = 0; i < mobilKerja.length; i++) {
            System.out.print("Mobil yang dapat dikerjakan di workstation " + (i + 1) + ": ");
            mobilKerja[i] = scan.nextInt();
        }
        System.out.println("");
        for (int i = 0; i < mobilMasuk.length; i++) {
            System.out.print("Mobil yang akan masuk ke workstation " + (i + 1) + ": ");
            mobilMasuk[i] = scan.nextInt();
        }
        System.out.println("");

        //karakter untuk tipe mobil
        char[] tipeMobil = new char[jmlTipe];
        for (int i = 0; i < jmlTipe; i++) {
            tipeMobil[i] = (char) (65 + i);
        }

        //untuk tiap tipe, masukkan mobil yang akan diproduksi dan kebutuhan optionnya
        int[] produksiPerTipe = new int[jmlTipe];
        int[][] matriksTipeOption = new int[jmlTipe][jmlOption];
        for (int i = 0; i < jmlTipe; i++) {
            System.out.println("Untuk mobil tipe " + tipeMobil[i] + ": ");
            System.out.print("    Banyaknya mobil yang diproduksi: ");
            int prod = scan.nextInt();
            int tempTotalMobil = totalMobil;
            tempTotalMobil -= prod;
            if (tempTotalMobil >= 0) {
                produksiPerTipe[i] = prod;
            } else {
                System.out.println("JUMLAH MOBIL PER TIPE MELEBIHI TOTAL MOBIL YANG DIPRODUKSI");
                break;
            }
            System.out.print("    Urutan matriks berdasarkan optionnya: ");
            for (int j = 0; j < jmlOption; j++) {
                matriksTipeOption[i][j] = scan.nextInt();
            }
        }
        System.out.println("");

        //Perhitungan Dasar CSP
        CSPCounter csp = new CSPCounter(jmlOption);
        System.out.print("Berdasarkan perhitungan CSP, average utility dari soal tersebut adalah ");
        System.out.println(csp.countCSP(produksiPerTipe, matriksTipeOption, totalMobil, mobilKerja, mobilMasuk));

        System.out.println("");

        //Tes inisialisasi kromosom
//        Kromosom krom = new Kromosom(totalMobil, produksiPerTipe);
//        for(int i=0; i<krom.gen.length; i++){
//            System.out.print(krom.gen[i] + " ");
//        }
        //Tes inisialisasi populasi
//        Populasi pop = new Populasi();
//        pop.inisialisasiPopulasi(4, totalMobil, produksiPerTipe);
//        for(int i=0; i<pop.kromosom.length; i++){
//            for(int j=0; j<pop.kromosom[i].gen.length; j++){
//                System.out.print(pop.kromosom[i].gen[j] + " ");
//            }
//            System.out.println("");
//        }
        //Tes buat hitung fitness
//        Kromosom krom = new Kromosom(totalMobil, produksiPerTipe);
//        krom.hitungFitnessKromosom(mobilKerja, mobilMasuk, matriksTipeOption);
//        System.out.println(krom.gagalDikerjakan);
//        for (int i = 0; i < krom.gen.length; i++) {
//            for (int j = 0; j < krom.urutan[i].length; j++) {
//                System.out.print(krom.urutan[i][j] + " ");
//            }
//            System.out.println("");
//        }
        //Tes buat hitung kromosom terbaik
//        Populasi pop = new Populasi();
//        pop.inisialisasiPopulasi(500, totalMobil, produksiPerTipe);
//        pop.hitungFitness(mobilKerja, mobilMasuk, matriksTipeOption);
//        Kromosom kromTerbaik = pop.kromTerbaik;
//        Kromosom kromTerbaikKedua = pop.kromTerbaikKedua;
//        
//        System.out.println(pop.jmlGagalKromosom);
//        for (int i = 0; i < kromTerbaik.gen.length; i++) {
//            for (int j = 0; j < kromTerbaik.urutan[i].length; j++) {
//                System.out.print(kromTerbaik.urutan[i][j] + " ");
//            }
//            System.out.println("");
//        }
//        System.out.println("");
//        System.out.println(pop.jmlGagalKromosomKedua);
//        for (int i = 0; i < kromTerbaikKedua.gen.length; i++) {
//            for (int j = 0; j < kromTerbaikKedua.urutan[i].length; j++) {
//                System.out.print(kromTerbaikKedua.urutan[i][j] + " ");
//            }
//            System.out.println("");
//        }
        //Tes Crossover
//        GeneticAlgorithm ga = new GeneticAlgorithm();
//        ga.populasi.inisialisasiPopulasi(10, totalMobil, produksiPerTipe);
//        ga.populasi.hitungFitness(mobilKerja, mobilMasuk, matriksTipeOption);
//        ga.selection();
//        ga.crossover();
//
//        System.out.println(ga.kromTerbaik.gagalDikerjakan);
//        for (int i = 0; i < ga.kromTerbaik.gen.length; i++) {
//            for (int j = 0; j < ga.kromTerbaik.urutan[i].length; j++) {
//                System.out.print(ga.kromTerbaik.urutan[i][j] + " ");
//            }
//            System.out.println("");
//        }
//        System.out.println("");
//        System.out.println(ga.kromTerbaikKedua.gagalDikerjakan);
//        for (int i = 0; i < ga.kromTerbaikKedua.gen.length; i++) {
//            for (int j = 0; j < ga.kromTerbaikKedua.urutan[i].length; j++) {
//                System.out.print(ga.kromTerbaikKedua.urutan[i][j] + " ");
//            }
//            System.out.println("");
//        }

        //jalankan sisanya dengan genetic algorithm dan simulated annealing

        Populasi pop = new Populasi();
        pop.inisialisasiPopulasi(5000, totalMobil, produksiPerTipe);
        Kromosom[] initPop = pop.kromosom;
        
        System.out.println("GENETIC ALGORITHM");
        //Genetic Algorithm
        double gaStart = System.currentTimeMillis();
        
        GeneticAlgorithm ga = new GeneticAlgorithm();
        ga.getSolution(initPop, mobilKerja, mobilMasuk, matriksTipeOption);
        
        double gaStop = System.currentTimeMillis();

        for (int i = 0; i < ga.populasi.kromTerbaik.gen.length; i++) {
            for (int j = 0; j < ga.populasi.kromTerbaik.tempMasuk.length; j++) {
                System.out.print(ga.populasi.kromTerbaik.urutan[i][j] + " ");
            }
            System.out.println("");
        }
        
        System.out.println("");
        
        System.out.println("SIMULATED ANNEALING");
        //Simulated Annealing
        double saStart = System.currentTimeMillis();
        
        SimulatedAnnealing sa = new SimulatedAnnealing();
        
        sa.inisialisasiVariabel(initPop);
        
//        System.out.println("Jumlah urutan yang gagal dikerjakan di Initial Solution: " + sa.initialSolution.gagalDikerjakan);
//        System.out.println("Temperatur awal: " + sa.initialTemp + " derajat.");
//        System.out.println("Setiap perulangan temperatur berkurang sebanyak " + sa.selisihTemp + " derajat.");
//        System.out.println("Untuk setiap pengurangan temperatur, akan terjadi perulangan sebanyak " + sa.repetitionSch + " kali.");
//        System.out.println("");
        
        sa.getSolution(mobilKerja, mobilMasuk, matriksTipeOption);
        
//        System.out.println("Solusi terakhir memiliki " + sa.initialSolution.gagalDikerjakan + " urutan yang gagal dikerjakan.");
//        System.out.println("");
        
        double saStop = System.currentTimeMillis();
        
        for (int i = 0; i < sa.initialSolution.gen.length; i++) {
            for (int j = 0; j < sa.initialSolution.tempMasuk.length; j++) {
                System.out.print(sa.initialSolution.urutan[i][j] + " ");
            }
            System.out.println("");
        }
        
        System.out.println("");
        
        System.out.println("HYBRID GA-SA");
        //Hybrid GA-SA
        double gasaStart = System.currentTimeMillis();
        
        HybridGASA gasa = new HybridGASA(initPop, 5000);
        gasa.solutionGASA(mobilKerja, mobilMasuk, matriksTipeOption);
        
        double gasaStop = System.currentTimeMillis();

        System.out.println(gasa.hasilTerbaik.gagalDikerjakan);
        for (int i = 0; i < gasa.hasilTerbaik.gen.length; i++) {
            for (int j = 0; j < gasa.hasilTerbaik.tempMasuk.length; j++) {
                System.out.print(gasa.hasilTerbaik.urutan[i][j] + " ");
            }
            System.out.println("");
        }

        System.out.println("");

        System.out.println("HYBRID SA-GA");
        //Hybrid SA-GA
        double sagaStart = System.currentTimeMillis();
        
        HybridSAGA saga = new HybridSAGA(initPop, 5000);
        saga.solutionSAGA(mobilKerja, mobilMasuk, matriksTipeOption);
        
        double sagaStop = System.currentTimeMillis();

        System.out.println(saga.hasilTerbaik.gagalDikerjakan);
        for (int i = 0; i < saga.hasilTerbaik.gen.length; i++) {
            for (int j = 0; j < saga.hasilTerbaik.tempMasuk.length; j++) {
                System.out.print(saga.hasilTerbaik.urutan[i][j] + " ");
            }
            System.out.println("");
        }

        System.out.println("");

        System.out.println("CYCLIC GA-SA");
        //Cyclic GA-SA
        double cyclicStart = System.currentTimeMillis();
        
        CyclicGASA cyclic = new CyclicGASA(initPop, 5000, 10);
        cyclic.solutionCyclic(mobilKerja, mobilMasuk, matriksTipeOption);
        
        double cyclicStop = System.currentTimeMillis();
        
        System.out.println(cyclic.hasilTerbaik.gagalDikerjakan);
        for (int i = 0; i < cyclic.hasilTerbaik.gen.length; i++) {
            for (int j = 0; j < cyclic.hasilTerbaik.tempMasuk.length; j++) {
                System.out.print(cyclic.hasilTerbaik.urutan[i][j] + " ");
            }
            System.out.println("");
        }
        
        System.out.println("");
        
        System.out.println("Waktu untuk mengerjakan: ");
        System.out.println("Genetic Algorithm: " + ((gaStop - gaStart) / 1000) + " detik");
        System.out.println("Simulated Annealing: " + ((saStop - saStart) / 1000) + " detik");
        System.out.println("Hybrid GA-SA: " + ((gasaStop - gasaStart) / 1000) + " detik");
        System.out.println("Hybrid SA-GA: " + ((sagaStop - sagaStart) / 1000) + " detik");
        System.out.println("Cyclic GA-SA: " + ((cyclicStop - cyclicStart) / 1000) + " detik");
        System.out.println("");
        System.out.println("Total waktu: " + ((cyclicStop - gaStart) / 1000) + " detik");
    }

}
