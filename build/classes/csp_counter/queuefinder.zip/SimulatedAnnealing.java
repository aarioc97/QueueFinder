/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queuefinder;

import java.util.Random;

/**
 *
 * @author i15055
 */
public class SimulatedAnnealing {

    Populasi populasi;
    Kromosom initialSolution, neighborSolution;
    int kromCounter, temperatureCounter, initialTemp, selisihTemp, repetitionSch, selisihFitness;

    public void inisialisasiVariabel(Kromosom[] initPop) {

        this.populasi = new Populasi();
        this.populasi.kromosom = initPop;

        this.kromCounter = 0;

        //Tentukan solusi awal
        this.initialSolution = this.populasi.kromosom[this.kromCounter];
        //Inisialisasi temperature change counter
        this.temperatureCounter = 0;

        Random rn = new Random();

        //Tentukan jadwal penurunan temperatur
        //temperatur akan turun sesuai dengan selisih yang ditentukan
        //selisih penurunan temperatur adalah nilai random
        //untuk kasus ini, maksimal selisih adalah 10, minimalnya 1
        this.selisihTemp = rn.nextInt(9) + 1 /*10*/;

        //Tentukan temperatur awal
        //temperatur awal adalah banyaknya kromosom di populasi
        this.initialTemp = this.populasi.kromosom.length /*rn.nextInt(100) + 100*/ /*200*/;

        //Tentukan jadwal repetisi
        //yaitu banyaknya iterasi yang dilakukan untuk setiap penurunan temperatur
        //nilai jadwal repetisi ditentukan secara random
        //minimal 1 kali, maksimal banyaknya kromosom di populasi dikurangi 1
        this.repetitionSch = rn.nextInt(this.populasi.kromosom.length - 1) + 1 /*50*/;

    }

    private void cariDeltaFitness(int[] mobilKerja, int[] mobilMasuk, int[][] matriksTipeOption) {
        this.initialSolution.hitungFitnessKromosom(mobilKerja, mobilMasuk, matriksTipeOption);
        this.neighborSolution.hitungFitnessKromosom(mobilKerja, mobilMasuk, matriksTipeOption);
        this.selisihFitness = this.neighborSolution.gagalDikerjakan - this.initialSolution.gagalDikerjakan;
    }

    private double hitungKemungkinan() {
        return Math.exp(Math.negateExact(this.selisihFitness) / this.selisihTemp);
    }

    private void tentukanSolusiAwal() {
        if (this.selisihFitness <= 0) {
            this.initialSolution = this.neighborSolution;
        }
        if (this.selisihFitness > 0) {
            if (this.hitungKemungkinan() == 1.0) {
                this.initialSolution = this.neighborSolution;
            }
        }
    }

    public void getSolution(int[] mobilKerja, int[] mobilMasuk, int[][] matriksTipeOption) {

        //Temperatur akan diturunkan hingga mencapai 0
        for (int i = this.initialTemp; i > 0; i = -this.selisihTemp) {
            //Untuk setiap penurunan temperatur, akan terjadi pengulangan
            //sebanyak jadwal repetisi
            for (int j = this.repetitionSch; j > 0; j--) {
                //Tetangga dari solusi awal adalah kromosom lain dalam populasi.
                //Untuk sementara, pengambilan solusi tetangga secara urutan.
                //PR: PENGAMBILAN SOLUSI TETANGGA SECARA RANDOM!
                this.kromCounter++;
                this.neighborSolution = this.populasi.kromosom[this.kromCounter];
                //Hitung fitness dari masing-masing kromosom
                //lalu tentukan deltanya
                this.cariDeltaFitness(mobilKerja, mobilMasuk, matriksTipeOption);
                //Tentukan apakah solusi awal diganti dengan neighbor atau tidak
                this.tentukanSolusiAwal();
            }
            this.kromCounter = 0;
        }

    }

}
